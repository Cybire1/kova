"use strict";(()=>{window.addEventListener("message",t=>{if(t.source!==window)return;let e=t.data;if(e?.target!=="kova-bridge"||typeof e.id!="number"||typeof e.method!="string")return;let a=e.id;chrome.runtime.sendMessage({type:"rpc",method:e.method,params:e.params}).then(o=>{let i=o?.ok?o.value:{error:{code:-32603,message:o?.error??"Kova didn\u2019t answer."}};window.postMessage({target:"kova-inpage",id:a,...i},window.location.origin)}).catch(()=>{window.postMessage({target:"kova-inpage",id:a,error:{code:4900,message:"Kova is off. Reload the page."}},window.location.origin)})});chrome.runtime.onMessage.addListener(t=>{t?.type==="kova-event"&&window.postMessage({target:"kova-inpage",event:t.event,payload:t.data},window.location.origin),t?.type==="kova-toast"&&t.title&&l(t.title,t.body??"",t.tone==="paid")});var d='<svg viewBox="0 0 200 200" width="18" height="18" aria-hidden="true"><path d="M62 46V154" stroke="#ECE8E1" stroke-width="19" stroke-linecap="round" fill="none"/><path d="M92.6 74.3A40 40 0 0 1 92.6 125.7M115.6 55A70 70 0 0 1 115.6 145M138.6 35.7A100 100 0 0 1 138.6 164.3" stroke="#D46558" stroke-width="17" stroke-linecap="round" fill="none"/></svg>';function l(t,e,a){let o=document.createElement("div");o.style.cssText="position:fixed;right:20px;bottom:20px;z-index:2147483647";let i=o.attachShadow({mode:"closed"}),r=matchMedia("(prefers-color-scheme: dark)").matches;i.innerHTML=`
<style>
.t{width:300px;box-sizing:border-box;border-radius:18px;padding:14px;font:500 13px/1.4 Manrope,ui-sans-serif,system-ui,-apple-system,sans-serif;
background:${r?"#161616":"#F4F2EE"};color:${r?"#ECE8E1":"#0B1A1D"};
box-shadow:0 2px 6px rgba(11,26,29,.06),0 40px 80px -30px rgba(11,26,29,.45),inset 0 0 0 1px ${r?"rgba(236,232,225,.08)":"rgba(11,26,29,.08)"};
animation:in .7s cubic-bezier(.32,.72,0,1) both}
.t.out{animation:out .45s cubic-bezier(.32,.72,0,1) forwards}
@keyframes in{from{opacity:0;transform:translateY(14px) scale(.98)}}
@keyframes out{to{opacity:0;transform:translateY(10px)}}
.r{display:flex;align-items:center;gap:10px}
.k{width:30px;height:30px;border-radius:9px;background:#0B1A1D;display:grid;place-items:center;flex:none}
b{display:block;font-weight:600;font-size:14px}
small{display:block;color:${r?"#9E998F":"#5F6B6E"};font-size:12px;margin-top:1px}
.m{height:4px;border-radius:4px;background:${r?"rgba(236,232,225,.1)":"rgba(11,26,29,.08)"};margin-top:12px;overflow:hidden}
.m i{display:block;height:100%;width:0;background:${a?"#D46558":"#949C9E"};border-radius:4px;animation:fill 1.2s cubic-bezier(.32,.72,0,1) .3s forwards}
@keyframes fill{to{width:100%}}
button{all:unset;cursor:pointer;margin-left:auto;width:26px;height:26px;border-radius:50%;display:grid;place-items:center;color:inherit;opacity:.5}
button:hover{opacity:1}
</style>
<div class="t" role="status"><div class="r"><span class="k">${d}</span><span><b></b><small></small></span><button aria-label="Close">\u2715</button></div><div class="m"><i></i></div></div>`;let s=i.querySelector(".t");i.querySelector("b").textContent=t,i.querySelector("small").textContent=e;let n=()=>{s.classList.add("out"),setTimeout(()=>o.remove(),450)};i.querySelector("button").addEventListener("click",n),document.documentElement.appendChild(o),setTimeout(n,6500)}})();
